package gov.nasa.jpf.shell.util;

public class JointOwnership {

  public JointOwnership(Object... c){

  }
}
