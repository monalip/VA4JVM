# Installing the NetBeans JPF plugin #
 1. Download and install [jpf-core](../jpf-core/index), e.g. from the [Mercurial repository](../install/repositories)
 2. -------------- take a break ---------------
 3. Download the `gov-nasa-jpf-netbeans-runjpf.nbm` file from [here](http://babelfish.arc.nasa.gov/trac/jpf/attachment/wiki/install/netbeans-plugin/gov-nasa-jpf-netbeans-runjpf.nbm).
 4. From within Netbeans go to **Tools**->**Plugins** (Alt+T followed by Alt+g)
 5. Select the **Downloaded** tab
 6. Click on **Add Plugins...** (Alt+A)
 7. Select the `gov-nasa-jpf-netbeans-runjpf.nbm` file that was downloaded in step 3
 8. Select **install**
 9. Agree to the License agreement
 10. Restart Netbeans